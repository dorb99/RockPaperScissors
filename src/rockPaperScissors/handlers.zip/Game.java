package rockPaperScissors;

import com.sun.net.httpserver.HttpExchange;

import java.io.IOException;
import java.util.ArrayList;
import java.util.UUID;

import org.json.JSONObject;

public class Game {
	
	static ArrayList<Game> games = new ArrayList<Game>();
	
	// NOT GOOD PRACTICE, USE GETTERS AND SETTERS!!!
	public HttpExchange player1;
	public HttpExchange player2;
	
	private String name1;
	private String name2;
	
	// NOT GOOD PRACTICE, USE GETTERS AND SETTERS!!!
	public String action1 = "";
	public String action2= "";
	
	private String id;
	
	
	public Game(HttpExchange player1, HttpExchange player2) throws IOException {
		this.player1 = player1;
		this.player2 = player2;
		this.name1 = getValueByKey(player1, "name");
		this.name2 = getValueByKey(player2, "name");
		createGameId();
		games.add(this);
	}


	private String getValueByKey(HttpExchange player, String key) throws IOException {
		byte[] data = player.getRequestBody().readAllBytes();	
		String body = new String(data);
		JSONObject json = new JSONObject(body);
		String value = json.getString(key);
		if(value.isBlank()) {
			return key;
		} else {
			return value;
		}
	}


	private void createGameId() throws IOException {
		UUID id = new UUID((long) this.name1.length(), (long) this.name2.length());
		this.id = id.toString();
	}
	
	public String getId() {
		return this.id;
	}
	
	static public boolean isValidId(String id) {
		for (Game game : games) {
			if(game.id == id) {
				return true;
			}
		}
		return false;
	}
	
	static public Game returnGame(String id) {
		for (Game i : games) {
			if(i.getId().equals(id)) {
				return i;
			}
		}
		return null;
	}
	
	public void play(HttpExchange exchange, String id) throws IOException {
		Game currentGame = Game.returnGame(id);
		if(currentGame == null) {
			return;
		}
		// DIDNT VALIDATED ACTION!!!
		String action = currentGame.getValueByKey(exchange, "action");
		if(currentGame.action1.isBlank()) {
			currentGame.action1 = action.toLowerCase();
			currentGame.player1 = exchange;
		} else {
			currentGame.action2 = action.toLowerCase();
			currentGame.player2 = exchange;
			currentGame.resolve();
		}
	}


	private void resolve() throws IOException {
		// USING STATIC STRINGS AND NOT WRITING
		String winner = "TIE";
		switch(this.action1) {
			case "rock":
				if(action2 == "paper") {
					winner = name2;
				} else if (action2 == "scissor") {
					winner = name1;
				}
				break;
			case "paper":
				if(action2 == "rock") {
					winner = name1;
				} else if (action2 == "scissor") {
					winner = name2;
				}
				break;
			case "scissor":
				if(action2 == "rock") {
					winner = name2;
				} else if (action2 == "paper") {
					winner = name1;
				}
				break;
		}
		player1.sendResponseHeaders(400, winner.length());
		player1.getResponseBody().write(winner.getBytes());
		player2.sendResponseHeaders(400, winner.length());
		player2.getResponseBody().write(winner.getBytes());
	}
}
