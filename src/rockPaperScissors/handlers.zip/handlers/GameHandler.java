package rockPaperScissors.handlers;

import java.io.IOException;
import java.util.Arrays;

import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpHandler;

import rockPaperScissors.Game;

public class GameHandler  implements HttpHandler{
	
	static private String POST_METHOD = "POST";
	static private HttpExchange waitingPlayerExchange = null;
	static private boolean waitingPlayer = false;
	
	// POST /game/join
	//		{"", "game", "join"}
	// POST /game/play/{id}
	//		{"", "game", "play", "{id}"}
	
	@Override
	public void handle(HttpExchange exchange) throws IOException {
//		try {
		System.out.println("Got request");
		System.out.println("REQUEST:" +exchange.getRequestURI());
//		CorsAdded.implemetntCors(exchange);
		if(exchange.getRequestMethod().equalsIgnoreCase(POST_METHOD)) {
			String path = exchange.getRequestURI().getPath();
			String[] pathParts = path.split("/");
			
			
			if(pathParts[0].isEmpty() && pathParts[1].equalsIgnoreCase("game") && pathParts[2].equalsIgnoreCase("join")) {
				joinGame(exchange);
			} else if(pathParts[0].isEmpty() && pathParts[1].equalsIgnoreCase("game") && pathParts[2].equalsIgnoreCase("play")) {
				String id = pathParts[3];
//				if(!Game.isValidId(id)){
//					sendResponse(exchange, "Not a real game!");
//				}
				System.out.println("sending action");
				playAction(exchange, id);
			} else {
				sendResponse(exchange, "Not a route!");
			}
			
		} else {
			sendResponse(exchange, "Not a valid method");
		}
	}
//	} finally {
//		
//	}
	
	private void sendResponse(HttpExchange exchange, String response) throws IOException {
		exchange.sendResponseHeaders(400, response.length());
		exchange.getResponseBody().write(response.getBytes());
	}

	private void playAction(HttpExchange exchange, String id) throws IOException {
		// go to the game, find my game, and play the action. return result when finihsed
		Game myGame = null;
		try {
			myGame = Game.returnGame(id);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		myGame.play(exchange, id);		
	}

	private void joinGame(HttpExchange exchange) throws IOException {
		// TODO Auto-generated method stub
		// if another user is waiting - if yes, create a game with him. else, wait
		if(!waitingPlayer) {
			waitingPlayer = true;
			waitingPlayerExchange = exchange;
		} else {
			Game currentGame = new Game(exchange, waitingPlayerExchange);
			sendResponse(exchange, currentGame.getId());
			sendResponse(waitingPlayerExchange, currentGame.getId());
			waitingPlayer = false;
			waitingPlayerExchange = null;
		}
	}

}