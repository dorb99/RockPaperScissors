package rockPaperScissors.handlers;

import java.io.IOException;

import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpHandler;

public class ScoreHandler implements HttpHandler{

	@Override
	public void handle(HttpExchange exchange) throws IOException {
		
	}

}